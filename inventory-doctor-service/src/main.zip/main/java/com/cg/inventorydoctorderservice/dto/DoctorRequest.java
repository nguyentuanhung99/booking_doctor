package com.cg.inventorydoctorderservice.dto;


import com.cg.inventorydoctorderservice.entity.Doctor;

import lombok.Data;

@Data
public class DoctorRequest extends Doctor {
}