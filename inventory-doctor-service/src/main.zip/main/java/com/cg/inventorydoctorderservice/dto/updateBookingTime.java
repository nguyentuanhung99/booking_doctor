package com.cg.inventorydoctorderservice.dto;

import java.util.Date;

import lombok.Data;
@Data
public class updateBookingTime {

    private Integer id;

    private Date booking_time;
}
